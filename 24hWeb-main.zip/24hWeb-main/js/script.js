
function afficher(){
    document.querySelector('#autres').classList.remove("hide");
    document.querySelector("#moins").classList.remove("hide");
    document.querySelector("#plus").classList.add("hide");
}

function reduire(){
    document.querySelector('#autres').classList.add("hide");
    document.querySelector("#moins").classList.add("hide");
    document.querySelector("#plus").classList.remove("hide");
}

function clair() {
    // Sélectionne tous les éléments avec la classe "clair"
    const clairElements = document.querySelectorAll(".clair");
    clairElements.forEach(element => {
        element.classList.remove("hide");  // Retire la classe "hide" des éléments avec "clair"
    });

    // Sélectionne tous les éléments avec la classe "sombre"
    const sombreElements = document.querySelectorAll(".sombre");
    sombreElements.forEach(element => {
        element.classList.add("hide");  // Ajoute la classe "hide" aux éléments avec "sombre"
    });
}

function sombre() {
    // Sélectionne tous les éléments avec la classe "clair"
    const clairElements = document.querySelectorAll(".clair");
    clairElements.forEach(element => {
        element.classList.add("hide");  // Ajoute la classe "hide" aux éléments avec "clair"
    });
     document.body.style.background = "linear-gradient(90deg,rgb(222, 18, 18) 0%, rgba(40, 41, 97, 1) 100%)"; 
    // Sélectionne tous les éléments avec la classe "sombre"
    const sombreElements = document.querySelectorAll(".sombre");
    sombreElements.forEach(element => {
        element.classList.remove("hide");  // Retire la classe "hide" des éléments avec "sombre"
    });
}
